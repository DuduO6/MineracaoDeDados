"""Project configuration."""


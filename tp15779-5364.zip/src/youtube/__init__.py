"""YouTube collection modules."""

